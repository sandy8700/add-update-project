import { useState } from 'react';
import './App.css'
import AddNewItems from './components/AddNewItem'
import ListItems from './components/ListItems'
import { dataLists } from './data';

function App() {
  const [cards, setCards] = useState(dataLists);

  const handleDelete = (name) => {
      const updatedCards = cards.filter((card) => card.name !== name);
     // console.log(updatedCards);
    setCards(updatedCards);
  };

  const handleNewItem = (itemName, itemArtists, itemDescription, itemId) => {
    // console.log(`New Item Added: ${itemName} Description:${itemDescription}`);
    const newItems = [
       ...cards,
      { id: itemId + 1, name: itemName, artist: itemArtists, description: itemDescription },
    ];
    setCards([...cards, newItems]);
  };
  return (
    <>
      <AddNewItems onNewItem={handleNewItem}></AddNewItems>
      <ListItems handleDelete={handleDelete} itemsData={cards}></ListItems>
    </>
  )
}

export default App
