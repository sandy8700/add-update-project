const ListItems = ({ itemsData, handleDelete }) => {
  return (
    <>
      <div className="container mt-5">
        <div className="flex">
          {itemsData.map((card) => (
            <div className="card" key={card.name}>
              <img src={card.url} alt={card.alt} />
              <h4>
                {card.name} by {card.artist}
              </h4>
              <p>{card.description}</p>
              <button
                onClick={() => handleDelete(card.name)}
                style={{
                  backgroundColor: "red",
                  padding: "7px 20px",
                  color: "white",
                  marginBottom: "20px",
                }}>
                Delete
              </button>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};
export default ListItems;
