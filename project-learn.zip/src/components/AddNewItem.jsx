import { useState } from "react";
// import { dataLists } from "../data";

const AddNewItems = ({ onNewItem }) => {
  const [name, setName] = useState();
  const [artist, setArtist] = useState();
  const [description, setDescription] = useState();

  const handleNameChange = (event) => {
    setName(event.target.value);
  };

  const handleArtistChange = (event) => {
    setArtist(event.target.value);
  };
  const handleDesChange = (event) => {
    setDescription(event.target.value);
  };

  const handleAddButtonClicked = () => {
    onNewItem(name, artist, description);
    setArtist("");
    setName("");
    setDescription("");
  };

  return (
    <>
      <div className="container text-center">
        <h2 className="mb-3">Add Items</h2>
        <div className="row">
          <div className="col-12 mb-3">
            <input
              type="text"
              placeholder="Enter Name Here"
              value={name}
              onChange={handleNameChange}
              className="form-control"
            />
          </div>
          <div className="col-12 mb-3">
            <input
              type="text"
              placeholder="Enter artists Here"
              className="form-control"
              value={artist}
              onChange={handleArtistChange}
            />
          </div>
          <div className="col-12 mb-3">
            <textarea
              className="form-control"
              placeholder="Description"
              value={description}
              onChange={handleDesChange}
            />
          </div>
          <div className="">
            <button
              type="button"
              className="btn btn-success kg-button px-3"
              onClick={handleAddButtonClicked}>
              Add
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
export default AddNewItems;
